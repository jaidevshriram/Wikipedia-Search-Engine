# Wikipedia-Search-Engine

Wikipedia Search Engine

## How to Run

### Indexing

bash index.sh <path to dump> <inverted index folder> <index stat file>

### Search

bash search.py <inverted index folder> "<query>"

## Requirements

- pystemmer